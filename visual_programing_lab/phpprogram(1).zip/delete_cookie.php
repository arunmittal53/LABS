<?php
$name = "user3";
setcookie($name,null,time()-3600,"/");
?>