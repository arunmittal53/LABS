<html>
<head>

</head>
<body>
	<form method="post">
		Name : <input type="text" name="name">
		<input type="submit" value="Submit">
	</form>	
</body>
</html>
<?php
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$name = $_POST["name"];
		if(!isset($_COOKIE[$name])) {
	        echo "Cookie named '" . $name . "' is not set!";
	    }
	    else {
	        echo "Cookie '" . $name . "' is set!<br>";
	    	echo "Value is: " . $_COOKIE[$name];
		}
}
?>