<?php
$file = fopen("a.txt","r") or die("unable to open!!");
$another = fopen("b.txt","w") or die("unable to open!!");
while(!feof($file)){
	$content = fgets($file);
	fwrite($another, $content);
}
fclose($another);
fclose($file);
?>