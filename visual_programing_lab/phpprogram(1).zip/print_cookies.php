<?php
	if($_COOKIE){
	print_r($_COOKIE);
	}
	else{
	echo "not set";
	}
?>