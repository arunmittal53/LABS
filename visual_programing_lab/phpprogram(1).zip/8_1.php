<?php
	$name_cookie = "user1";
	$cookie_value = "Arun";
	setcookie($name_cookie,$cookie_value,time()+86400,"/");	
	$name_cookie = "user2";
	$cookie_value = "Varun";
	setcookie($name_cookie,$cookie_value,time()+86400,"/");
	$name_cookie = "user3";
	$cookie_value = "Raman";
	setcookie($name_cookie,$cookie_value,time()+86400,"/");
	$name_cookie = "user4";
	$cookie_value = "Rahul";
	setcookie($name_cookie,$cookie_value,time()+86400);
?>
<html>
<body>

<?php
/*if(!isset($_COOKIE[$name_cookie])) {
    echo "Cookie named '" . $name_cookie . "' is not set!";
} else {
    echo "Cookie '" . $name_cookie . "' is set!<br>";
    echo "Value is: " . $_COOKIE[$name_cookie];
}*/
if($_COOKIE) {
  print_r($_COOKIE);     //print all cookie
}
else
{
   echo "COOKIE is not set";    
}
?>

</body>
</html>