<html>
<body>
<?php

$name = $_POST["name"];
if (empty($_POST["name"])) {
	$nameError = "Name is required";
	echo "$nameError";
	}
	else{
		echo "Name :    ";
		echo"$name"	;
}
echo "<br>";
$password = $_POST["password"];
if(empty($password)){
	echo "password required";
}
else if(strlen($password) < 8){
	echo "Password must be at least 8 digits long";
}
else{
	echo "Password  :   ";
	echo "$password";
}
?>
</body>
</html>