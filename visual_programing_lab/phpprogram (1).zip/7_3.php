<?php

$file = fopen("writting_file.txt","w") or die("u!!");
$name ="arun mittal\n";
$branch ="IT\n";
fwrite($file,$name);
fwrite($file,$branch);
fclose($file);
echo "done";
?>