<?php
	
$myfile = fopen("text_file.txt","r") or die("unable to open file!!");
while(!feof($myfile)) {
  echo fgets($myfile) . "<br>";
}
fclose($myfile);
?>