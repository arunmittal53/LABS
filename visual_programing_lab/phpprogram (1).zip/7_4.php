<?php

$file = fopen("a.txt","r") or die("unable to open!!");
fclose($file);
$another = fopen("b.txt","w");
fwrite($another,$file);
fclose($another);
f

?>