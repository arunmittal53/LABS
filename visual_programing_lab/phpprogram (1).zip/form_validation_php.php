<?php
    //if ($_SERVER["REQUEST_METHOD"] == "POST") {
    	$flag =0;
    	$passwordError ="password required";
    	$nameError = "Name required";
    	$name = $_POST["name"];
    	$password = $_POST["password"];
    	if (empty($_POST["name"])) {
    		echo "$nameError";
    		$flag =1;
    	}
    	echo "<br>";
    	if(empty($password)){
    		echo "password required";
    		$flag =1;
    	}
    	else if(strlen($password) < 8){
    		echo "Password must be at least 8 digits long";
    		$flag =1;
    	}

    	if($flag ==0)
    	{
    		echo "Name :   $name<br>";
    		echo "Password :    $password";
    	}

    	if($flag == 1) 
    	{
   /* } else {
    	echo "get";
    }*/
?>
	<html>
	<body>

	<form method="post" action="">
		Name : <input type="text" name="name">    <?php  echo "       $nameError"?> <br>
		Password : <input type="password" name="password">      <?php  echo "       $passwordError"?> <br>
		<input type="submit" name="Submit">
	</form>
	</body>
	</html>
<?php
    }
?>