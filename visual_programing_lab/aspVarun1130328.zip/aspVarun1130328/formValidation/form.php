<!--
    * Created by: Varun kumar
    * Date: 30 march, 2016
-->
<?php
    $flag = 0;
    $name = $_POST['name'];
    $nameError = "";
    if ($name == '') {
    	$nameError = "Name is mandatory";
    	$flag = 1;
    } else if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
        $nameError = "Only letters and white space allowed"; 
        $flag = 1;
    }
    $password = $_POST['password'];
    $passwordError = "";
    if ($password == '') {
    	$passwordError = "Password is mandatory";
    	$flag = 1;
    } else if (strlen($password) < 8) {
    	$passwordError = "Password must be at least 8 digits long";
    	$flag = 1;
    }/* else if (ctype_digit($password) == true) {
        $flag = 1;
        $passwordError = "Password must be alpha numeric";
    }*/
    $email = $_POST['email'];
    $emailError = "";
    if ($email == '') {
    	$emailError = "Email is mandatory";
    	$flag = 1;
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailError = "Invalid email format"; 
        $flag = 1;
    }
    $phone = $_POST['phone'];
    $phoneError = "";
    if ($phone == '') {
    	$phoneError = "Phone number is mandatory";
    	$flag = 1;
    } else if (ctype_digit($phone) == false || strlen($phone) != 10) {
    	$phoneError = "Enter a valid phone number";
    	$flag = 1;
    }
    $pin = $_POST['pin'];
    $pinError = "";
    if ($pin == '') {
    	$pinError = "PIN code is mandatory";
    	$flag = 1;
    } else if (ctype_digit($pin) == false || strlen($pin) != 6) {
    	$phoneError = "PIN number must be 6 digits long";
    	$flag = 1;
    }
    //success
    if ($flag == 0) {
    	echo "<p>Successfully submitted the form</p>";
    	echo "<p>Name: $name</p>";
    	echo "<p>Password: $password</p>";
    	echo "<p>Email: $email</p>";
    	echo "<p>Phone Number: $phone</p>";
    	echo "<p>PIN Number: $pin</p>";
    }
    //showing the form when there is validation error
    if ($flag == 1) {
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Form validation in PHP</title>
        <style>
            body {
            	font: :"times new roman";
            	text-align: center;
            }
        </style>
    </head>
    <body>
        <h2>Form Validation in PHP</h2>
        <form method="post" action="">
            <p>
                <input type="text" name="name" placeholder="Enter your name">
                <?php
                    echo $nameError;
                ?>
            </p>
            <p>
                <input type="password" name="password" placeholder="Choose a password">
                <?php
                    echo $passwordError;
                ?>
            </p>
            <p>
                <input type="text" name="email" placeholder="Enter email-id">
                <?php
                    echo $emailError;
                ?>
            </p>
            <p>
                <input type="text" name="phone" placeholder="Enter your phone no">
                <?php
                    echo $phoneError;
                ?>
            </p>
            <p>
                <input type="text" name="pin" placeholder="Enter PIN code">
                <?php
                    echo $pinError;
                ?>
            </p>
            <p>
                <input type="submit" value="submit">
            </p>
        </form>
    </body>
</html>
<?php
    }
?>