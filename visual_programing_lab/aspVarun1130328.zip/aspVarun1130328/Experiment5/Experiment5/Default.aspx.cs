﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Experiment5
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie myCookie = Request.Cookies["myCookie"];
            if (myCookie != null)
            {
                Label1.Text =  myCookie.Value;
            }
            else
            {
                Label1.Text = "not found";
            }

        }

        protected void ButtonDelete_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = Response.Cookies["myCookie"];
            cookie.Expires = DateTime.Now.AddSeconds(-1);
            Response.Redirect("Default.aspx");
        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            string value = TextBox1.Text;
            HttpCookie cookie = new HttpCookie("myCookie");
            cookie.Value = value;
            cookie.Expires = DateTime.Now.AddSeconds(200);
            Response.Cookies.Add(cookie);
            Response.Redirect("Default.aspx");
        }
    }
}
