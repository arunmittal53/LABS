﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Experiment2
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                LabelMessage.Text = "Thank you for registration";
            }
            else
            {
                LabelMessage.Text = "Fill all the details correctly";
            }
        }
        protected void validateAddress(Object sender, ServerValidateEventArgs e)
        {
            if (e.Value.Length >= 10)
            {
                e.IsValid = true;
            }
            else
            {
                e.IsValid = false;
            }
        }
    }
}
