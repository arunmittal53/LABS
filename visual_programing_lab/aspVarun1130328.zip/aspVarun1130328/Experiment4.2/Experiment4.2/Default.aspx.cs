﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Experiment4._2
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int[] a = {1, 3, 6};
            //object m = null;
            //string s = m.ToString();
            try
            {
                Label1.Text = a[4].ToString();
            }
            catch (Exception e1) {
                Response.Redirect("error.html");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            double celsius;
            try
            {
                celsius = double.Parse(TextBox1.Text);
            }
            catch (Exception e1)
            {
                celsius = 0;
            }
            //Label2.Text = celsius.ToString();
            WebService1 proxy = new WebService1();
            double fahrenheit = proxy.CelsiusToFahrenheit(celsius);
            Label2.Text = fahrenheit.ToString();
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            double fahrenheit;
            try
            {
                fahrenheit = double.Parse(TextBox3.Text);
            }
            catch (Exception e1)
            {
                fahrenheit = 0;
            }
            WebService1 proxy = new WebService1();
            double celsius = proxy.FahrenheitToCelsius(fahrenheit);
            Label4.Text = celsius.ToString();
        }
    }
}
