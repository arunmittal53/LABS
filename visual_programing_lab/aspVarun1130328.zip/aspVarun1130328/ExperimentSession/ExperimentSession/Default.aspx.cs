﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExperimentSession
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var ipAddress = Request.UserHostAddress;
            var hostName = Request.UserHostName;
            var useragent = Request.UserAgent;
            string value = "IP Address: " + ipAddress + "<br>" +
                "host name: " + hostName + "<br>" +
                "user Agent: " + useragent;
            Label1.Text = value;
        }
    }
}
