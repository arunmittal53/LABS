<?php
    $myFile = fopen("story.txt", "r") or die("Unable to open file");
    $count = 0;
    $a = array();
    while (!feof($myFile)) {
        $word = fgetc($myFile);
        array_push($a, $word);
        echo $word;
    }
    //print_r($a);
    $size = sizeof($a);
    //echo count($a);
    /*foreach ($a as $key) {
    	echo $key;
    }*/
    for ($i = 0; $i < $size - 3; $i++) {
    	//echo $a[$i];
    	if (($a[$i] == 't' || $a[$i] == 'T') && ($a[$i + 1] == 'h' || $a[$i + 1] == 'H') && ($a[$i + 2] == 'e' || $a[$i + 2] == 'E') && ($a[$i + 3] == ' ') || ($a[$i + 3] == '')) {
    		$count++;
    	}
    }
    echo "Total count of word 'the' (case ignored) is $count";
?>