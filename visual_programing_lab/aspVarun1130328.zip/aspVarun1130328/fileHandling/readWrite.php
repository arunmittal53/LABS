<?php
    $myFile1 = fopen("nitkkr.txt", "r") or die("Unable to open file");
    $myFile2 = fopen("learningPHP.txt", "w");
    while (!feof($myFile1)) {
    	$text = fgets($myFile1);
    	fwrite($myFile2, $text);
    }
    echo "Successfully written";
    fclose($myFile1);
    fclose($myFile2);
?>