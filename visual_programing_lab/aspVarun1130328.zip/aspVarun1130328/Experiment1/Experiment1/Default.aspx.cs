﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Experiment1
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Button2.Attributes.Add("onmouseover", "this.style.background='Green'");
            Button2.Attributes.Add("onmouseout", "this.style.background='Yellow'");

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            String item = ListBox1.SelectedItem.ToString();
            //String name = Label1.Text;
            Label1.Text = "You selected " + item;
            //dp.InnerHtml = "Hi " + name + "! " + "You selected " + item;
        }

        protected void centerBT_Click(object sender, EventArgs e)
        {
            Label2.Text = Label2.Text + "Welcome To Radiant";
        }

        protected void ListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListBox2.SelectedIndex == 0)
            {
                Label3.Text = "Orange";
            }
            else if (ListBox2.SelectedIndex == 1)
            {
                Label3.Text = "mango";
            }
            else if (ListBox2.SelectedIndex == 2)
            {
                Label3.Text = "kiwi";
            }
            else
            {
                Label3.Text = "banana";
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            String item = ListBox2.SelectedItem.ToString();
            Label3.Text = "Rs 60";
            if (item == "Orange")
            {
                Label3.Text = "Rs 20";
                Image1.ImageUrl = "~/Images/pic1.jpg";
            }
            else if(item == "Banana")
            {
                Label3.Text = "Rs 50";
                Image1.ImageUrl = "~/Images/pic2.jpg";
            }
            else if (item == "Mango")
            {
                Label3.Text = "Rs 500";
                Image1.ImageUrl = "~/Images/pic3.jpg";
            }
            else if (item == "Kiwi")
            {
                Label3.Text = "Rs 10";
                Image1.ImageUrl = "~/Images/pic4.jpg";
            }
            else
            {
                Label3.Text = "Rs 90";
            }

        }
       
    }
}
