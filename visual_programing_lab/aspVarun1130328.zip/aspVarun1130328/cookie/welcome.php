<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo 'post';
    } else {
?>
    <!DOCTYPE html>
    <html>
        <head>
            <title>Owl city</title>
        </head>
        <body>
            <h1>Hey hi!</h1>
            <p>Don't try to be smart</p>
            <p>Login first</p>
        </body>
    </html>
<?php
    }
?>
