<?php
    $cookieName = 'username';
    if (!isset($_COOKIE[$cookieName])) {
        echo 'cookie not found';
    }
    else {
        echo 'cookie is set<br>';
        echo 'value is ' . $_COOKIE[$cookieName];
    }
?>
