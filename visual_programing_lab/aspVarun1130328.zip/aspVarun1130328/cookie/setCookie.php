<?php
    $cookieName = 'username';
    $cookieValue = 'varun kumar gupta';
    setcookie($cookieName, $cookieValue, time() + 30000, '/');
    echo 'cookie is set<br>';
?>
