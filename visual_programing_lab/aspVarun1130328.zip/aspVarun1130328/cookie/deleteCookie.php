<?php
    $cookieName = 'username';
    $cookieValue = 'varun kumar gupta';
    setcookie($cookieName, $cookieValue, time() - 3600, '/');
    echo 'cookie deleted<br>';
?>
